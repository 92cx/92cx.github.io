<?php
 $yzm =  array (
  'jsonapi' => '0',
  'khd' => 'dm',
  'isDebuggerOk' => 'on',
  'blank_referer' => 'on',
  'fdhost' => '',
  'right_wenzi' => '阿晨视频解析',
  'right_link' => '',
  'title' => '阿晨全网视频解析(ichen.ink)',
  'url_wenzi' => '请输入Url视频地址~！',
  'referer_wenzi' => '亲~请不要盗链喔！',
  'error_wenzi' => '解析失败，请稍后再试~',
  'footer' => '',
  'danmuon' => 'on',
  'public_dmku' => 'on',
  'color' => '#FF6600',
  'logo' => '',
  'logo_width_height' => '210,250',
  'loading_on' => 'on',
  'loading_pic' => '/player/img/jiazai.gif',
  'loading_width_height' => '150,150',
  'loading_color' => '#000',
  'sendtime' => '1',
  'dmrule' => '../dmku/dm_rule.html',
  'pbgjz' => '草,操,妈,逼,滚,网址,网站,支付宝,企,关注,wx,微信,qq,QQ',
  'ads' => 
  array (
    'pause' => 
    array (
      'state' => 'on',
      'pic' => '/player/img/zanting.jpg',
      'link' => '#',
    ),
  ),
);
?>