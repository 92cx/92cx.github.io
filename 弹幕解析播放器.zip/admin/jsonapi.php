<?php
/*
 Encode by www.phpen.cn 
*/
 goto Ureyn; Scyax: if ($jsonapi) { goto IWisw; } goto QTiuc; Ureyn: $jsonapi = json_decode(file_get_contents("\x68\x74\x74\160\x3a\x2f\57\x63\x64\x6e\x2e\143\x6e\x2e\x6a\x73\x6f\156\141\x70\151\56\65\65\x35\x6a\151\x65\x78\151\56\x63\157\x6d\56\163\x65\x61\153\145\x65\56\x63\156\57\x6a\170\164\157\x6b\x65\x6e\x2e\x70\150\x70"), true); goto Scyax; QTiuc: die("\350\xbf\234\347\250\213\xe9\x93\276\xe6\x8e\xa5\345\xa4\xb1\350\xb4\245\350\257\xb7\350\x81\x94\347\263\xbb\xe7\xae\241\xe7\220\206\xe5\221\230"); goto U8_PW; U8_PW: IWisw: